package com.rieltor.domain.model

import kotlinx.serialization.Serializable
import java.io.InputStream

@Serializable
data class StoredTokens(
    val openId: String,
    val accessToken: String,
    val refreshToken: String,
    val accessTokenExpiresAt: Long,
    val refreshTokenExpiresAt: Long,
)

@Serializable
data class StoredGoogleDriveTokens(
    val accessToken: String,
    val refreshToken: String,
    val accessTokenExpiresAt: Long,
)

@Serializable
data class StoredThreadsTokens(
    val userId: String,
    val accessToken: String,
    val accessTokenExpiresAt: Long,
)

enum class RepostDestination {
    TIKTOK,
    THREADS,
}

/** Null messageThreadId means that every message in the chat is monitored. */
data class TelegramMonitoredTopic(
    val chatId: Long,
    val messageThreadId: Long? = null,
) {
    fun matches(chatId: Long, messageThreadId: Long): Boolean =
        this.chatId == chatId &&
            (this.messageThreadId == null || this.messageThreadId == messageThreadId)
}

data class TelegramPhoto(
    val fileName: String,
    val content: InputStream,
    val localPath: String? = null,
)

data class MediaTextOverlay(
    val title: String,
    val price: String?,
    val contact: String,
)

/**
 * Public, destination-independent representation of a property listing.
 *
 * Source contacts and internal commercial notes must be removed before this model is built.
 */
data class ListingMessage(
    val title: String,
    val price: String,
    val address: String?,
    val keyParameters: List<String>,
    val additionalParameters: List<String>,
    val governmentPrograms: String?,
    val registration: String?,
    val hashtags: List<String>,
    val phone: String,
)

data class StoredMedia(
    val publicUrl: String,
    val localPath: String,
)

data class PublishReceipt(
    val publishId: String,
    val creatorName: String,
    val privacyLevel: String,
    val destination: RepostDestination = RepostDestination.TIKTOK,
)

data class RepostFailure(
    val destination: RepostDestination,
    val reason: String,
)

sealed interface RepostResult {
    data class Published(
        val receipts: List<PublishReceipt>,
        val failures: List<RepostFailure> = emptyList(),
    ) : RepostResult {
        val receipt: PublishReceipt get() = receipts.first()
    }
    data object IgnoredSource : RepostResult
    data object IgnoredContent : RepostResult
    data object Duplicate : RepostResult
}
