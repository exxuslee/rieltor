package com.rieltor.infrastructure.media

import java.nio.file.Files
import java.nio.file.attribute.FileTime
import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.time.ZoneOffset
import kotlin.io.path.createDirectory
import kotlin.io.path.createFile
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import com.rieltor.infrastructure.job.CleanupJob as MediaCleanupJob

class CleanupJobTest {

    @Test
    fun `deletes only supported images older than thirty days`() {
        val directory = Files.createTempDirectory("media-cleanup-test")
        val now = Instant.parse("2026-08-28T12:00:00Z")
        val oldImage = directory.resolve("old.jpg").createFile()
        val freshImage = directory.resolve("fresh.webp").createFile()
        val oldOtherFile = directory.resolve("old.txt").createFile()
        val nestedDirectory = directory.resolve("nested").createDirectory()
        val nestedOldImage = nestedDirectory.resolve("old.png").createFile()

        FileTime.from(now.minus(Duration.ofDays(35))).also { oldTime ->
            Files.setLastModifiedTime(oldImage, oldTime)
            Files.setLastModifiedTime(oldOtherFile, oldTime)
            Files.setLastModifiedTime(nestedOldImage, oldTime)
        }
        Files.setLastModifiedTime(freshImage, FileTime.from(now.minus(Duration.ofHours(23))))

        val cleanup = MediaCleanupJob(
            directory = directory,
            clock = Clock.fixed(now, ZoneOffset.UTC),
        )

        try {
            assertEquals(1, cleanup.cleanNow())
            assertFalse(Files.exists(oldImage))
            assertTrue(Files.exists(freshImage))
            assertTrue(Files.exists(oldOtherFile))
            assertTrue(Files.exists(nestedOldImage))
        } finally {
            cleanup.close()
            directory.toFile().deleteRecursively()
        }
    }

    @Test
    fun `keeps image exactly one day old`() {
        val directory = Files.createTempDirectory("media-cleanup-boundary-test")
        val now = Instant.parse("2026-08-28T12:00:00Z")
        val image = directory.resolve("boundary.png").createFile()
        Files.setLastModifiedTime(image, FileTime.from(now.minus(Duration.ofDays(1))))
        val cleanup = MediaCleanupJob(
            directory = directory,
            maxAge = Duration.ofDays(1),
            clock = Clock.fixed(now, ZoneOffset.UTC),
        )

        try {
            assertEquals(0, cleanup.cleanNow())
            assertTrue(Files.exists(image))
        } finally {
            cleanup.close()
            directory.toFile().deleteRecursively()
        }
    }

    @Test fun `active catalog photo is retained regardless of age`() {
        val directory = Files.createTempDirectory("catalog-media-retention")
        val image = directory.resolve("active.jpg").createFile()
        Files.setLastModifiedTime(image, FileTime.from(Instant.parse("2020-01-01T00:00:00Z")))
        MediaCleanupJob(directory, referencedFiles = { setOf("active.jpg") }).use {
            assertEquals(0, it.cleanNow())
            assertTrue(Files.exists(image))
        }
    }
}
